# Canvas de module pour PrestaShop 1.6

Exemple simple.
